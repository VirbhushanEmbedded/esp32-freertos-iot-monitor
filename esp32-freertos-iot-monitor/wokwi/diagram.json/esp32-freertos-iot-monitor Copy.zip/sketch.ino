#include <Arduino.h>
#include <DHT.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define DHTPIN 4
#define DHTTYPE DHT22
#define BUTTON_PIN 15
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

DHT dht(DHTPIN, DHTTYPE);
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

QueueHandle_t sensorQueue;
QueueHandle_t buttonQueue;

struct SensorData {
  float temperature;
  float humidity;
};

// Task 1 - Read DHT22 every 2s
void sensorTask(void *pvParameters) {
  SensorData data;
  while (1) {
    data.temperature = dht.readTemperature();
    data.humidity = dht.readHumidity();
    if (!isnan(data.temperature) && !isnan(data.humidity)) {
      xQueueSend(sensorQueue, &data, portMAX_DELAY);
    }
    vTaskDelay(pdMS_TO_TICKS(2000));
  }
}

// Task 2 - Monitor button with debounce
void buttonTask(void *pvParameters) {
  bool lastState = HIGH;
  bool currentState;
  int pressCount = 0;
  while (1) {
    currentState = digitalRead(BUTTON_PIN);
    if (currentState == LOW && lastState == HIGH) {
      vTaskDelay(pdMS_TO_TICKS(50)); // debounce
      if (digitalRead(BUTTON_PIN) == LOW) {
        pressCount++;
        xQueueSend(buttonQueue, &pressCount, portMAX_DELAY);
      }
    }
    lastState = currentState;
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}

// Task 3 - Update OLED display
void displayTask(void *pvParameters) {
  SensorData data;
  int pressCount = 0;
  float temp = 0, hum = 0;
  while (1) {
    if (xQueueReceive(sensorQueue, &data, 0) == pdTRUE) {
      temp = data.temperature;
      hum = data.humidity;
    }
    if (xQueueReceive(buttonQueue, &pressCount, 0) == pdTRUE) {
      // button press received
    }
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(WHITE);

    display.setCursor(0, 0);
    display.println("FreeRTOS Monitor");
    display.drawLine(0, 10, 127, 10, WHITE);

    display.setCursor(0, 16);
    display.print("Temp: ");
    display.print(temp, 1);
    display.println(" C");

    display.setCursor(0, 30);
    display.print("Hum:  ");
    display.print(hum, 1);
    display.println(" %");

    display.setCursor(0, 44);
    display.print("Btn Presses: ");
    display.println(pressCount);

    display.display();
    vTaskDelay(pdMS_TO_TICKS(200));
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  dht.begin();

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED failed");
    while (1);
  }

  display.clearDisplay();
  display.display();

  sensorQueue = xQueueCreate(5, sizeof(SensorData));
  buttonQueue = xQueueCreate(5, sizeof(int));

  xTaskCreate(sensorTask,  "SensorTask",  2048, NULL, 1, NULL);
  xTaskCreate(buttonTask,  "ButtonTask",  2048, NULL, 1, NULL);
  xTaskCreate(displayTask, "DisplayTask", 2048, NULL, 1, NULL);
}

void loop() {
  // FreeRTOS takes over, loop stays empty
}